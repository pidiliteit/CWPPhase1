﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Activities;
using System.ServiceModel;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient();
            Guid instanceid = (Guid)proxy.Operation1();
            //proxy.Operation1();
            //WorkflowControlEndpoint ep = new WorkflowControlEndpoint(new BasicHttpBinding(), new EndpointAddress("http://localhost:8089/TestWF/wce"));
            //WorkflowControlClient client = new WorkflowControlClient(ep);
            
            //client.Suspend(instanceid);
            Console.WriteLine("Client Done");
            Console.ReadLine();
            //client.Unsuspend(instanceid);
            
        }
    }
}
