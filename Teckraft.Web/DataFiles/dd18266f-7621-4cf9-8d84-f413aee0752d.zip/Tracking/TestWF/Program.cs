﻿using System;
using System.Linq;
using System.Activities;
using System.Activities.Statements;
using System.ServiceModel.Activities;
using System.ServiceModel.Description;
using System.ServiceModel;
using System.Activities.DurableInstancing;
using System.Runtime.DurableInstancing;
using System.ServiceModel.Activities.Description;
using System.Activities.Tracking;
using System.Collections;
using System.Text;
using System.IO;
using System.Collections.Generic;

namespace TestWF
{

    class Program
    {
        static void Main(string[] args)
        {

            string baseAddress = "http://localhost:8089/TestWF";

            using (WorkflowServiceHost host =
            new WorkflowServiceHost(new Workflow1(), new Uri(baseAddress)))
            {
                host.Description.Behaviors.Add(new
                ServiceMetadataBehavior() { HttpGetEnabled = true });
                host.Description.Behaviors.Add(new ServiceBehaviorAttribute() { IncludeExceptionDetailInFaults = true });
                host.AddServiceEndpoint("IService", new BasicHttpBinding(), baseAddress);
                
                TrackingProfile fileTrackingProfile = new TrackingProfile();
                fileTrackingProfile.Queries.Add(new WorkflowInstanceQuery
                {
                    States = { "*" }
                });
                fileTrackingProfile.Queries.Add(new ActivityStateQuery()
                {
                    ActivityName = "*",
                    States = { "*" },
                    // You can use the following to specify specific stages:
                    // States = {
                    // ActivityStates.Executing,
                    // ActivityStates.Closed
                    //},
                    Variables =
{
{ "*" }
} // or you can enter specific variable names instead of “*”

                });
                fileTrackingProfile.Queries.Add(new CustomTrackingQuery()
                {
                    ActivityName = "*",
                    Name = "*"
                });

                FileTrackingParticipant fileTrackingParticipant =
                new FileTrackingParticipant();
                fileTrackingParticipant.TrackingProfile = fileTrackingProfile;
                host.WorkflowExtensions.Add(fileTrackingParticipant);


                host.Description.Behaviors.Add(new WorkflowIdleBehavior()
                {
                    TimeToPersist = TimeSpan.FromSeconds(5),
                    TimeToUnload = TimeSpan.FromSeconds(20)
                });


                host.Open();
                Console.WriteLine("Car rental service listening at: " +
                baseAddress);
                Console.WriteLine("Press ENTER to exit");
                Console.ReadLine();
            }

        }
    }

    public class FileTrackingParticipant : TrackingParticipant
    {
        string fileName;
        protected override void Track(TrackingRecord record,
        TimeSpan timeout)
        {
            fileName = @"c:\tracking\" + record.InstanceId + ".tracking";
            using (StreamWriter sw = File.AppendText(fileName))
            {
                WorkflowInstanceRecord workflowInstanceRecord = record as WorkflowInstanceRecord;
                if (workflowInstanceRecord != null)
                {
                    sw.WriteLine("------WorkflowInstanceRecord------");
                    sw.WriteLine("Workflow InstanceID: {0} Workflow instance state: {1}",
                    record.InstanceId, workflowInstanceRecord.State);
                    sw.WriteLine("\n");
                }

                ActivityStateRecord activityStateRecord = record as ActivityStateRecord;
                if (activityStateRecord != null)
                {
                    IDictionary<string,object> variables = activityStateRecord.Variables;
                    StringBuilder vars = new StringBuilder();
                    
                    if (variables.Count > 0)
                    {
                        vars.AppendLine("\n\tVariables:");
                        foreach (KeyValuePair<string,object> variable in variables)
                        {
                            vars.AppendLine(String.Format(
                            "\t\tName: {0} Value: {1}", variable.Key, variable.Value));
                        }
                    }

                    sw.WriteLine("------ActivityStateRecord------");
                    sw.WriteLine("Activity DisplayName: {0} :ActivityInstanceState: {1} {2}",
                    activityStateRecord.Activity.Name, activityStateRecord.State,
                    ((variables.Count > 0) ? vars.ToString() : String.Empty));
                    sw.WriteLine("\n");
                }

                CustomTrackingRecord customTrackingRecord = record as CustomTrackingRecord;
                if ((customTrackingRecord != null) && (customTrackingRecord.Data.Count > 0))
                {
                    sw.WriteLine("------CustomTrackingRecord------");
                    sw.WriteLine("\n\tUser Data:");
                    foreach (string data in customTrackingRecord.Data.Keys)
                    {
                        sw.WriteLine(" \t\t {0} : {1}", data, customTrackingRecord.Data[data]);
                    }
                    sw.WriteLine("\n");
                }
            }
        }
    }

}
